import React from 'react';
import './buttonSkeleton.css';

const ButtonLoaderSkeleton = () => {
    return (
        <>
            <div className="button-skeleton-wrapper">
                <div className="skeleton-button"></div>                
                <div className="skeleton-button"></div>                
                <div className="skeleton-button"></div>                
            </div>
        </>
    );
};

export default ButtonLoaderSkeleton;