import { createStore, combineReducers, applyMiddleware } from "redux";
import {thunk} from 'redux-thunk';
import {composeWithDevTools} from 'redux-devtools-extension';

import { getImagesReducer , getImagesByHashtag } from "./reducers/imageReducers";

const reducer = combineReducers({
    getImages: getImagesReducer,
    getImagesByHashtag: getImagesByHashtag
});

const middleware = [thunk];

const imageFromLocalStorage = localStorage.getItem("image")? JSON.parse(localStorage.getItem("image")): []
const INITIAL_STATE ={
    image:{
        imageItem:imageFromLocalStorage
    }
}

const store = createStore(
    reducer,
    INITIAL_STATE,
    composeWithDevTools(applyMiddleware(...middleware))
)

export default store;

