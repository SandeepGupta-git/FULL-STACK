import React from 'react';
import axios from 'axios';
import { useState } from 'react';


const SignupPage = () => {
    const btnLogin = {
        padding: "0.5rem 2rem",
        color: "#fff",
        background: "#04a528",
        border: "1px solid #777",
        marginTop: "10px",
        width: "100%",
        borderRadius:"5px"
    }

    const [email, setEmail] = useState("");
    const [password, setPass] = useState("");
    const [loginSucess, setLoginSuccess] = useState(null);
    const getLoginData = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/api/login", {
                email,
                password,
            });
            if (response.status === 200) {
                setLoginSuccess(true);
                console.log('>>>>>>>>>.', response.status);
                setTimeout(() => {
                    window.location.replace("http://localhost:3000/");
                }, 4000);

            } else {
                setLoginSuccess(false);
            }
        } catch (error) {
            console.log('Error:', error);
            setLoginSuccess(false);
        }
    }


    return (
        <div className="container-fluid">
            <div className="row">
                <div className="card mb-3">
                    <div className="row g-0">
                    <div className="col-md-3"></div>
                        <div className="col-md-6" style={{ position: "relative" }}>
                            <div className="card-body login-box">

                                <form onSubmit={(e) => getLoginData(e)}>
                                    <div style={{ display: 'flex', justifyContent: 'center', marginTop: '40px', alignItems: 'center', flexDirection: 'column' }} >
                                        <input type='email' placeholder='Enter Email' className='form-control' style={{ position: 'static', marginBottom: '10px' }} onChange={(e) => setEmail(e.target.value)} />
                                        <input type='password' placeholder='Enter Password' className='form-control' style={{ position: 'static', marginBottom: '10px' }} onChange={(e) => setPass(e.target.value)} />
                                        <button type='submit' style={btnLogin}>Sign In</button>
                                        <div>
                                            {loginSucess === null ? <></> :
                                                loginSucess !== null && loginSucess === true ? <h2>Login is Success. Redirecting to Dasboard!!</h2> :
                                                    <h3>Wrong credentials Provided, Please Check again... </h3>}
                                        </div>
                                    </div>
                                </form>

                            </div>

                        </div>
                        <div className="col-md-3"></div>
                    </div>
                </div>
            </div>
            <br/>
            <br/>
            <br/>
        </div>
    )
}
export default SignupPage;