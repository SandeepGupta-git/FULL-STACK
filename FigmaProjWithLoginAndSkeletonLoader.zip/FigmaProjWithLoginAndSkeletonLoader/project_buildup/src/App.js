
import './App.css';
import LoginPage from './Pages/LoginPage'
import SignupPage from './Pages/SignupPage';
import HomePage from './Pages/HomePage'

import HeaderComp from './Component/HeaderComp'
import { useState } from 'react';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import ImageByHashtagScreen from './Pages/ImageByHashtagScreen';



function App() {
  return (
    <div className="App">
      <HeaderComp/>
      <main>
      
      <Routes>
        
    
      {/* <Route  path='/' element={<HeaderComp/>}> */}
        <Route path='/' index element={<HomePage/>}/>
        <Route path='/login' element={<LoginPage/>}/>
        <Route path='/signup' element={<SignupPage/>}/>
        <Route path='/imageByHashtagScreen/:hashtag' element={<ImageByHashtagScreen/>}/>
        

     
      </Routes>
    
      </main>
    </div>
  );
}

export default App;