// const loginUserDataModel = require("../imageModel/loginModel");
const SignupUserDataModel = require("../imageModel/signupModel")

const LoginController = async (req, res) => {
    const loginObjData = req.body;
    const { email, password} = loginObjData;
    console.log('---=====>>>>', email, password);
    try {
      const user = await SignupUserDataModel.findOne({ email, password });
      
      if (user) {
        // User exists
        res.status(200).json({ message: 'Login successful' });
      } else {
        // User does not exist or invalid credentials
        res.status(401).json({ message: 'Invalid email or password' });
      }
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  }
module.exports = LoginController;
