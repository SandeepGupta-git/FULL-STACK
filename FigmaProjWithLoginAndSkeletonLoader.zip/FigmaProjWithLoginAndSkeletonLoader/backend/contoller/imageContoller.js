const imageFigma = require('../imageModel/imagemodel');

const getAllImages = async(req, res) => {
	try {
		const ImageFigma = await imageFigma.find({});
		res.json(ImageFigma);
	} catch(error) {
		console.error(error);
		res.status(500).json({message: "Server error"});
	}
}

const getImageByHashtag = async(req, res) => {
	try {
		const ImageFigmaByHashtag = await imageFigma.find({ "hashtag": { "$in": [req.params.hashtag]} });
		console.log('-->', ImageFigmaByHashtag);
		res.json(ImageFigmaByHashtag);
	} catch(error) {
		console.error(error);
		res.status(500).json({message: "Server error"});
	}
}
module.exports = {
	getAllImages,
	getImageByHashtag
}