
// const image1 = require('../../project_buildup/images/Cake.jpg') 
// const image2 = require('../../project_buildup/images/grapes.jpg') 
const imageFigma =[
    {
        hashtag:"Travel",
        image1url:"Image/Cake.jpg",
        image2url:"Image/grapes.jpg"
    },
    {
        hashtag:"Food",
        image1url: "Image/manchurian.jpg",
        image2url: "Image/noodles.jpg"
    }

]

module.exports = imageFigma;