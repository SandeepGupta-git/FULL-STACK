const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const connectDB = require('./config/Db');
const imageRoutes = require('./routes/imageRoutes');
const signupRouter = require('./routes/signupRoute');
connectDB();
const app = express();
// Middleware
app.use(cors()); // cross origin resource sharing (like from flipkart to any payment gateway such as paypal)
app.use(express.json());
app.use('/api/imagefigma', imageRoutes);
app.use(signupRouter);
//================ SIGN UP BACKEND SETUP ================================================
// Define User Schema Step-1
// const signupUserSchema = new mongoose.Schema({
//   email: String,
//   password: String,
//   name: String,
//   mobile: String,
// });

//const SignupUserData = mongoose.model('Images-Figma-signup', signupUserSchema);

// Signup Controller , Step-2
// const signupController = async (req, res) => {
//   const signupObjData = req.body.signupUserData;
//   const { email, password, name, mobile } = signupObjData;
//   console.log('---------------->>>>', email, password, name, mobile);
//   try {
//     const newUser = new SignupUserData({ email, password, name, mobile });
//     console.log('->', newUser);
//     await newUser.save();
//     res.status(201).json({ message: 'User created successfully' });
//   } catch (error) {
//     res.status(500).json({ message: 'Error creating user' });
//   }
// }


// Signup Route 
//signupRouter.post('/api/signup', signupController);
// server.js file , Step-3
//app.use(signupRouter);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));