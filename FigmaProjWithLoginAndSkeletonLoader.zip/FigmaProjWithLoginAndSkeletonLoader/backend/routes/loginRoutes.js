const express  = require('express');
const LoginRouter = express.Router();
const LoginController = require('../contoller/loginController');


LoginRouter.post('/api/login', LoginController);

module.exports = LoginRouter;