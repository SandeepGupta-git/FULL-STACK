const express =require('express');
const router = express.Router();

const {getAllImages,getImageByHashtag} = require( "../contoller/imageContoller")

router.get("/" , getAllImages);
router.get("/:hashtag", getImageByHashtag);

module.exports = router;

