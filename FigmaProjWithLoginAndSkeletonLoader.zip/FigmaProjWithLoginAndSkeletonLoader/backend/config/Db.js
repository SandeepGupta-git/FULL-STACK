const mongoose = require('mongoose');

const MONGO_URI = process.env.MONGO_URI || "mongodb+srv://guptasandeep188:guptasandeep188@blogcluster.3gg4i.mongodb.net/FigmaProject?retryWrites=true&w=majority";
//const MONGO_URI = process.env.MONGO_URI || "mongodb+srv://kunalrmedhane:kunal1211@cluster0.fyz4btg.mongodb.net/FullStackMongoDatabase?retryWrites=true&w=majority";
//"mongodb+srv://kunalrmedhane:kunal1211@cluster0.fyz4btg.mongodb.net/FullStackMongoDatabase?retryWrites=true&w=majority";

const connectDB = async () => {
    try {
        /*
        useNewUrlParser: This option is used to parse the MongoDB connection string with the new parser. 
        It's recommended to set this option to true to avoid deprecation warnings.
        ​
        useUnifiedTopology: This option is used to enable the new Server Discovery 
        and Monitoring engine in MongoDB, 
        Setting this to true is also recommended for new applications.
        */
                const conn = await mongoose.connect(MONGO_URI, {
                    useNewUrlParser: true,
                    useUnifiedTopology: true
                }
                );
                console.log(` Mongo DB is connected!!! ${conn.connection.host} `);
            } catch (error) {
                console.error('Mongo DB connection Failed', error);
                process.exit(1);
            }
}

module.exports= connectDB