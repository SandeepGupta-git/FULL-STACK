const mongoose = require('mongoose');
const productSchema = new mongoose.Schema({
	name: {
		type: String,
		required: true
	},
	description: {
		type: String,
		required: true
	},
	price: {
		type: Number,
		required: true
	},
	countInStock: {
		type: Number,
		required: true
	},
	imageUrl: {
		type: String,
		required: true
	}
});
/*
The first parameter is set to 'mern-shopping-product'. 
This is the name that Mongoose will look for or create a collection in 
the MongoDB database with the name 
'mern-shopping-product' to store documents of this particular model.
*/
const Product = mongoose.model('mern-shopping-product', productSchema);
module.exports = Product;