const mongoose = require('mongoose');
/*

A MongoDB connection string typically consists of -
1. Protocol/Driver: The connection string begins with the protocol or driver identifier, 
which indicates the type of MongoDB driver being used.
e.g - mongodb+srv:

2. Username and Password: If your MongoDB deployment requires authentication, 
you provide the username and password in the connection string.
e.g - guptasandeep188:guptasandeep188

3. Host and Port: Specify the host and port of your MongoDB server. 
If you are using a replica set, you may provide multiple hosts.
e.g - blogcluster.3gg4i.mongodb.net

4. Database Name: Specify the name of the MongoDB database you want to connect to. 
This comes after the last slash ("/") in the connection string.
e.g - FullStackMongoDatabase

5.Options and Parameters:Additional options and parameters can be included to configure the connection. 
These might include options like retryWrites, w (write concern), authSource, and others.
e.g- ?retryWrites=true&w=majority

*/

const MONGO_URI = "mongodb+srv://guptasandeep188:guptasandeep188@blogcluster.3gg4i.mongodb.net/FullStackMongoDatabase?retryWrites=true&w=majority";
const connectDB = async() => {
	//console.log('->', process.env.MONGO_URI);
	try {
		const conn = await mongoose.connect(MONGO_URI, {
			useNewUrlParser: true,
			useUnifiedTopology: true
		});
		console.log(`Mongo DB is connected!!! ${conn.connection.host} `);
	} catch(error) {
		console.error('Mongo DB connection Failed', error);
		process.exit(1);
	}
}

module.exports = connectDB;