import * as actionTypes from '../constants/imageConstants'


export const getImagesReducer = (state= {images: []}, action)=>{
    //  console.log(action.payload);
    switch (action.type){
        case actionTypes.GET_IMAGES_REQUEST:
            return{
                loading:true,
                images:[]
            };
            case actionTypes.GET_IMAGES_SUCCESS:
                //console.log('hii data',action.payload)
                return{
                    loading:false,
                    images:action.payload
                };
                case actionTypes.GET_IMAGES_FAIL:
                    return{
                        loading:false,
                        error: action.payload
                    };
                    default:
                        return state;

    }
};
                                                                //1st change
export const getImagesByHashtag = (state = {imageByHashtagArray : []  } , action) => {
    console.log('reducer --------->>>>>', action.payload)
	switch (action.type) {
		case actionTypes.GET_IMAGESBYHASHTAG_REQUEST:
			return {
				loading: true,
                imageByHashtagArray: [] // 2nd change
			};
		case actionTypes.GET_IMAGESBYHASHTAG_SUCCESS:
			return {
				loading: false,
				imageByHashtagArray: action.payload
			};
		case actionTypes.GET_IMAGESBYHASHTAG_FAIL:
			return {
				loading: false,
				error: action.payload
			};
		default:
			return state;
	}
}