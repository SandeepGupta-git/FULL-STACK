import * as actionTypes from '../constants/imageConstants'
import axios from 'axios';

export const getImages= ()=> async (dispatch) => {
    //console.log("hi")
    try {
        dispatch({
            type:actionTypes.GET_IMAGES_REQUEST
        });
        const {data} = await axios.get("/api/imagefigma")
        //console.log('>',data)
        dispatch({
            type: actionTypes.GET_IMAGES_SUCCESS,
            payload: data
        });

}
catch(error){
    dispatch({
        type:actionTypes.GET_IMAGES_FAIL,
        payload: error.response && error.response.data.message ? error.response.data.message: error.message,
    });
}
}


 export const getImagesByHashtagAction = (hashtag) => async (dispatch) => {
       //console.log('Hashtagdata',hashtag)
     try {
         dispatch({
             type:actionTypes.GET_IMAGESBYHASHTAG_REQUEST
         });
          const {data} = await axios.get(`/api/imagefigma/${hashtag}`)
         dispatch({
             type: actionTypes.GET_IMAGESBYHASHTAG_SUCCESS,
             payload: data
         });

 }
 catch(error){
     dispatch({
         type:actionTypes.GET_IMAGESBYHASHTAG_FAIL,
         payload: error.response && error.response.data.message ? error.response.data.message: error.message,
     });
 }
 }

