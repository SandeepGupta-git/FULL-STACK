import React from 'react';
import './skeleton.css';

const ImageHashtagLoaderSkeleton = () => {
    return (
        <>
            <div className="skeleton-wrapper">
                <div className="skeleton-title"></div>
                <div className="skeleton-image"></div>
                <div className="skeleton-image"></div>
            </div>
            <div className="skeleton-wrapper">
                <div className="skeleton-title"></div>
                <div className="skeleton-image"></div>
                <div className="skeleton-image"></div>
            </div>
            <div className="skeleton-wrapper">
                <div className="skeleton-title"></div>
                <div className="skeleton-image"></div>
                <div className="skeleton-image"></div>
            </div>
        </>
    );
};

export default ImageHashtagLoaderSkeleton;