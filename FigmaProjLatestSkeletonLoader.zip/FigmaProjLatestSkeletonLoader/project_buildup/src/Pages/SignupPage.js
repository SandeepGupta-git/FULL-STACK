// import userImage from '../Image/userImage.jpg'
import React from 'react';
import axios from 'axios';
import { useState } from 'react';
import { jwtDecode } from 'jwt-decode';

const SignupPage = () => {
    const btnLogin = {
        padding: "0.8rem 2rem",
        color: "#fff",
        background: "#04a528",
        border: "1px solid #777",
        marginTop: "10px",
        width: "30%",
    }

    const [email, setEmail] = useState("");
    const [password, setPass] = useState("");
    const [name, setName] = useState("");
    const [mobile, setMob] = useState(null);
    const [signupSucess, setSignupSucess] = useState(null);
    const getSignupData = (e) => {
        e.preventDefault();
        axios.post("http://localhost:5000/api/signup/", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            signupUserData: {
                email,
                password,
                name,
                mobile
            },
        })
            .then(resp => {
                console.log(resp)
                setEmail("");
                setPass("");
                setName("");
                setMob("");
                console.log(email, password, name, mobile)
                setSignupSucess(resp.status);
            })
            .catch(err => console.log('something went wrong==', err))
    }


    return (
        <div className="container-fluid">
            <div className="row">
                <div className="card mb-3">
                    <div className="row g-0">

                        <div className="col-md-6" style={{ position: "relative" }}>
                            <div className="card-body login-box">

                                <form onSubmit={(e) => getSignupData(e)}>
                                    <div style={{ display: 'flex', justifyContent: 'center', marginTop: '80px', alignItems: 'center', flexDirection: 'column' }} >
                                        <input type='email' placeholder='Enter Email' className='form-control' style={{ position: 'static', marginBottom: '10px' }} onChange={(e) => setEmail(e.target.value)} />
                                        <input type='password' placeholder='Enter Password' className='form-control' style={{ position: 'static', marginBottom: '10px' }} onChange={(e) => setPass(e.target.value)} />
                                        <input type='text' placeholder='Enter Name' className='form-control' style={{ position: 'static', marginBottom: '10px' }} onChange={(e) => setName(e.target.value)} />
                                        <input type='text' placeholder='Enter Mobile' className='form-control' style={{ position: 'static' }} onChange={(e) => setMob(e.target.value)} />

                                        <button type='submit' style={btnLogin}>Sign In</button>
                                        <div>
                                            {signupSucess === null ? <></> :
                                                signupSucess !== null && signupSucess === 201 ? <h2>Registered!!</h2> :
                                                    <h3>Something went wrong!!!! </h3>}
                                        </div>
                                    </div>
                                </form>

                            </div>

                        </div>

                        <div className="col-md-6">
                            {/* <img src={} className="img-fluid rounded-start" alt="..." /> */}
                        </div>
                        <div style={{ marginLeft: '251px' }}>
                            {/* <GoogleOAuthProvider clientId='892544453603-4oqlbik6f3pjprcg0lbu0n5ngqkof2mg.apps.googleusercontent.com'>
                                <GoogleLogin onSuccess={credentialRespose => {
                                    const details = jwtDecode(credentialRespose.credential)
                                    console.log('===>>>', details);
                                    window.location.replace("http://localhost:3000")
                                }}
                                    onError={(err) => {
                                        console.log('login Failed', err);

                                    }}

                                >

                                </GoogleLogin>
                            </GoogleOAuthProvider> */}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default SignupPage;