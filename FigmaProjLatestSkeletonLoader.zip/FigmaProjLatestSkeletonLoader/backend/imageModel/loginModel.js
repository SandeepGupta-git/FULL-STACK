// const mongoose = require('mongoose');

// const LoginSchema = new mongoose.Schema({
//     email: String,
//     password: String,
   
//   });
// const LoginUserDataModel = mongoose.model('Images-Figma-signup', LoginSchema);

// module.exports = LoginUserDataModel;