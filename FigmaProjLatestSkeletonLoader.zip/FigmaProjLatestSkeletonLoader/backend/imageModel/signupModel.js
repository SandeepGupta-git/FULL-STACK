const mongoose = require('mongoose');

const signupUserSchema = new mongoose.Schema({
    email: String,
    password: String,
    name: String,
    mobile: String,
  });
const SignupUserDataModel = mongoose.model('Images-Figma-signup', signupUserSchema);

module.exports = SignupUserDataModel;