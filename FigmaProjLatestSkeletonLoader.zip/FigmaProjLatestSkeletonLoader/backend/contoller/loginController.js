// const loginUserDataModel = require("../imageModel/loginModel");
const SignupUserDataModel = require("../imageModel/signupModel")

const LoginController = async (req, res) => {
    const loginObjData = req.body;
    const { email, password} = loginObjData;
    console.log('---=====>>>>', email, password);
    try {
      const user = await SignupUserDataModel.findOne({ email, password });
      console.log("0=>", user);
      if (user) {
        // User exists
        res.status(200).json({ message: 'Login successful' });
        console.log("1=>",res);
      } else {
        // User does not exist or invalid credentials
        res.status(401).json({ message: 'Invalid email or password' });
        console.log("2=>",res);

      }
    } catch (err) {
      res.status(500).json({ message: err.message });
      console.log("3=>",res);

    }
  }
module.exports = LoginController;
