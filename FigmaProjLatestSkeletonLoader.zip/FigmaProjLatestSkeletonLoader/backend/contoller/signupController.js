const SignupUserDataModel = require("../imageModel/signupModel");


const signupController = async (req, res) => {
    const signupObjData = req.body.signupUserData;
    const { email, password, name, mobile } = signupObjData;
    console.log('---========>>>>>>>=====>>>>', email, password, name, mobile);
    try {
      const newUser = new SignupUserDataModel({ email, password, name, mobile });
      console.log('->', newUser);
      await newUser.save();
      res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Error creating user' });
    }
  }

module.exports = signupController;