const mongoose = require('mongoose');
const imageSchema = new mongoose.Schema({
    hashtag:{
        type:String,
        require:true
    },
    image1url:{
        type:String,
        require:true
    },
    image2url:{
        type:String,
        require:true
    }

})

const imageFigma = mongoose.model('Images-Figma',imageSchema);
module.exports = imageFigma;
