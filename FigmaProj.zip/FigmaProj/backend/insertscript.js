require('dotenv').config();

const imageData = require ( './imageData/imageData');

const connectDB = require ('./config/Db');

const imageFigma = require ( './imageModel/imagemodel')
connectDB();

const importData = async ()=> {
    try{
        await imageFigma.insertMany(imageData);
        console.log("Data Import sucess");
        process.exit();
        
    }  catch (error){
        console.error("Error Data Import");
        process.exit(1)
    }
}

importData();
