import './imageHashtagComp.css';


const ImageHashtagComp = ({ hashtag, image1url, image2url }) => {
    return (<div>
        <div class="card my-3">
            <h1 class="card-title" style={{ background: '#d3d3d3', textAlign: 'left', borderBottom: '2px solid #000' }}>{hashtag}</h1>
            <img src={image1url} class="card-img-top" alt="Image 1" style={{ height: '80vh', width: '98%', margin: '5px', border: '1px solid #777' }} />
            <img src={image2url} class="card-img-top" alt="Image 2" style={{ height: '80vh', width: '98%', margin: '5px', border: '1px solid #777' }} />

        </div>
    </div>)
};

export default ImageHashtagComp;


