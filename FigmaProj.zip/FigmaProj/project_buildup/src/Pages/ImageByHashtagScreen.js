
import React, { useEffect, useState } from 'react'
import { Link, Outlet, useParams } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'

import { getImagesByHashtagAction as listImagesByHashtag } from '../redux/actions/imageActions';


const ImageByHashtagScreen = () => {
  const dispatch = useDispatch();
  const imageByHashtagData = useSelector(state => state.getImagesByHashtag);
  const { imageByHashtagArray, loading, error } = imageByHashtagData;
  let params = useParams();
 
  //console.log(params)
  useEffect(() => {
    dispatch(listImagesByHashtag(params.hashtag));
  }, [dispatch, params.hashtag]);

  return (
    <div>
      <Outlet />
      <div className="hommescreen__products">
        {loading ? (<h2 className="loading">Loading...</h2>) :
          error ? (<h2>{error}</h2>) : 
          imageByHashtagArray.map((abc) => 
          <>
          <h2>{abc.hashtag}</h2>
          <img src={`/${abc.image1url}`} style={{width: "90%", height: "80vh", margin: "5px"}} />
          <img src={`/${abc.image2url}`} style={{width: "90%", height: "80vh", margin: "5px"}} />
          <span>{abc._id}</span>
          </>
          )
        }
      </div>
    </div>
  )
}

export default ImageByHashtagScreen;