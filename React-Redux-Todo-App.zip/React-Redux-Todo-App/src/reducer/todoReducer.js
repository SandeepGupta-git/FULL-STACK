import { ADDTODO, DELETETODO, TOGGLETODO } from "../action/actionTypes"

const initialState = []

const todoReducer = (state = initialState, action) => {
    switch (action.type) {
        case ADDTODO:
            return [
                ...state,
                action.payload
            ]
        case TOGGLETODO:
            return (
                state.map((todo) => (
                    todo.id === action.payload ? {
                        ...todo,
                        completed: !todo.completed
                    } : todo
                ))
            )
        case DELETETODO:
            return (
                state.filter((todo) => todo.id !== action.payload)
            )
        default:
            return state
    }

}

export default todoReducer;
