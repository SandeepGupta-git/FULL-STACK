export const ADDTODO = "ADDTODO";
export const TOGGLETODO = "TOGGLETODO";
export const DELETETODO = "DELETETODO";