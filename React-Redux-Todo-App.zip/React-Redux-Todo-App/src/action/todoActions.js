import { ADDTODO, TOGGLETODO, DELETETODO } from "./actionTypes"
export const addTodoActionCreator = (todoVal) => {
    console.log(todoVal);
    return {
        type: ADDTODO,
        payload: {
            id: Math.random(),
            name: todoVal,
            completed: false,
            date: new Date().toDateString()
        }
    }
}

export const toggleTodoActionCreator = (id) => {
    return {
        type: TOGGLETODO,
        payload: id
    }
}

export const deleteTodoActionCreator = (id) => {
    return {
        type: DELETETODO,
        payload: id
    }
}