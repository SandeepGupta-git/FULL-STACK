import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addTodoActionCreator, toggleTodoActionCreator, deleteTodoActionCreator } from "../action/todoActions";
const TodoComponent = () => {
    const todos = useSelector(state => state);
    console.log('todos', todos);
    const dispatch = useDispatch();
    console.log("todos", todos);
    const [todoText, setTodoText] = useState("");

    const addTodo = () => {
        if(todoText !== '') {
            dispatch(addTodoActionCreator(todoText));
            setTodoText('')
        } else {
            alert("please add todo")
        }
        
    }
    const toggleTodo = (id) => {
        dispatch(toggleTodoActionCreator(id))
    }
    const deleteTodo = (id) => {
        dispatch(deleteTodoActionCreator(id))
    }
    return (
        <div>
            <input type="text" value={todoText} onChange={(e) => setTodoText(e.target.value)} />
            <button type="button" onClick={() => addTodo()}>Add Todo</button>
            <ul>
                {
                    todos.map((i) => (
                        <li onClick={() => toggleTodo(i.id)} id={i.id}>
                            <input type="checkbox" checked={i.completed} />
                            <b>{i.name}</b>
                            <button type="button" onClick={() => deleteTodo(i.id)}>Delete</button>
                            {
                                i.completed && <span>Marked as completed!!!</span>
                            }
                        </li>
                    ))
                }

            </ul>
        </div>
    )
}

export default TodoComponent;