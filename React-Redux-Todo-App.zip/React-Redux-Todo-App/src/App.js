import logo from './logo.svg';
import './App.css';
import TodoComponent from './components/TodoComponent';

function App() {
  return (
    <div className="App">
      <TodoComponent />
    </div>
  );
}

export default App;
