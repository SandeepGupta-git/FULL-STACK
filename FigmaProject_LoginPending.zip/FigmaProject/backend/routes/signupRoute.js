const express  = require('express');
const signupRouter = express.Router();
const signupController = require('../contoller/signupController');

signupRouter.post('/api/signup', signupController);

module.exports = signupRouter;