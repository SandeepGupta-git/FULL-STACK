const express = require('express');
const cors = require('cors');
const connectDB = require('./config/Db');
const imageRoutes = require('./routes/imageRoutes');
const signupRouter = require('./routes/signupRoute');
connectDB();
const app = express();
// Middleware
app.use(cors()); // cross origin resource sharing (like from flipkart to any payment gateway such as paypal)
app.use(express.json());
app.use('/api/imagefigma', imageRoutes);
app.use(signupRouter);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));