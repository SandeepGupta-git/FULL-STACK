import userImage from '../userImage.jpg';
import { Link, Outlet } from "react-router-dom";


const Header = () => {
    return (
        <div className="HeaderComp">
         <nav class="fluid-container" style={{ display: 'flex' }}>
        <img src={userImage} className="img" alt="..." />

        <div class="card-img-overlay" style={{height:'5rem'}}>
          <h3 className='text-right' >#Hashtag </h3>

          <div className='fliud-container' style={{ float: "right", marginTop: " 57px", marginRight: "128px" }}>



           <button class="btn btn-outline-none dropdown-toggle mx-1" type="button" data-bs-toggle="dropdown" aria-expanded="false" style={{ color: "White" }} >
              Explore
            </button>
            <ul class="dropdown-menu" >
              <li><a class="dropdown-item" href="#">Action</a></li>
              <li><a class="dropdown-item" href="#">Another action</a></li>
              <li><a class="dropdown-item" href="#">Something else here</a></li>
            </ul>
            
            <Link to="/signup">  <button className='btn btn-sm btn-outline-secondary ' type="button" style={{ color: 'white', }}>Signup</button> </Link>
                <Link to="/login"><button className='btn btn-sm btn-outline-secondary mx-1' type="button" style={{ color: "White", }}>Login</button> </Link>
            

          </div>


          <div class="text-center" style={{ textAlign: "center" }}><h1> Let’s Find The Perfect Free Photo
            For You</h1></div>

          <div class="container">
            <form class="search" role="search">
              <input class="form-control me-2" type="search" border-radius="10px" placeholder="Search for all images on #Hastag" aria-label="Search" />
              <button class="btn btn-outline-none dropdown-toggle " type="button" data-bs-toggle="dropdown" aria-expanded="false" style={{
                color: "black", float: "right",

                marginTop: "-38px"
              }} >
                All Image
              </button>
              <ul class="dropdown-menu" >
                <li><a class="dropdown-item" href="#">Action</a></li>
                <li><a class="dropdown-item" href="#">Another action</a></li>
                <li><a class="dropdown-item" href="#">Something else here</a></li>
              </ul>
            </form>
          </div>

        </div>


      </nav>

        </div>
    )
}
export default Header;