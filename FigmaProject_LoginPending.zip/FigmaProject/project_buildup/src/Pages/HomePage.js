import './homePage.css'
import ImageHashtagComp from '../Component/ImageHashtagComp'
import { getImages as listimages } from '../redux/actions/imageActions';
import { useDispatch, useSelector } from 'react-redux'
import { useState, useEffect } from 'react'
import { Outlet, Link } from 'react-router-dom'


const HomePage = () => {
  const dispatch = useDispatch();
  const getImagesdata = useSelector(state => state.getImages);
  const { images, loading, error } = getImagesdata;
  useEffect(() => {
    dispatch(listimages())
  }, []);
  return (
    <div>
      <div style={{ marginTop: '15px' }}>
        <h3 style={{ float: 'left', marginLeft: '140px' }}>Popular Hashtags</h3>
        <div>
          {
            getImagesdata.images.map((val) => <Link to={`/imageByHashtagScreen/${val.hashtag}`} className="btn btn-sm btn-outline-secondary mx-2" type="button" style={{ letterSpacing: '2px', marginTop: '23px' }}>{val.hashtag}</Link>)
          }
        </div>
      </div >
      <div className='Screenimage'>
        {loading ? (<h2 className="loading">Loading Please wait...</h2>) :
          error ? (<h2>{error}</h2>) :
            getImagesdata.images.map((image) => <ImageHashtagComp
              hashtag={image.hashtag}
              image1url={image.image1url}
              image2url={image.image2url} />

            )}

      </div>
      <h1 style={{
        color: "#8A8A8A",

        fontFamily: "Red Rose", marginTop: "20px"
      }}>#Hashtag</h1>
      <h4 style={{
        color: "#8A8A8A",

        fontFamily: "Red Rose"
      }}>Make Something Awesome</h4>
      <Outlet />
    </div>
  )
}

export default HomePage;