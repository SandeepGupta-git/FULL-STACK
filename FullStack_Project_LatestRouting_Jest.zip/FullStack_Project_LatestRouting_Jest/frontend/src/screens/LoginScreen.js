import { useState, useRef } from "react";
function Login( ) {
    const inputStyle = {
        width: "60%",
        height: "2rem",
        margin: "10px"
    }
    const button = {
        width: "60%",
        height: "2rem",
        margin: "10px"
    }
    const {email, pass} = useRef("");
    function getEmail(e) {
        console.log(e.target.value);
    }
    return (
        <>
            <div className="container" style={{marginLeft: "22%", marginTop: "5%"}}>
                <div>
                <input type="email" value={email} placeholder="Email ID" style={{width: "60%", height: "2rem", margin : "10px"}} />
                </div>
                <div>
                <input type="text" value={pass} placeholder="password" style={inputStyle} />
                </div>            
                
               
                <button type="button" style={button}>Login</button>
            </div>
        </>
    )
};

export default Login;