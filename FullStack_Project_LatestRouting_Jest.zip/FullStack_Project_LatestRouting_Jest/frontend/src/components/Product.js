import './Product.css';
import { Link } from 'react-router-dom';

const Product = ({ productId, name, price, description, imageUrl, countInStock, label }) => {
	const pdtname = name;
	return (<div className="products">
		<img src={imageUrl} alt={name} className="product_image" />
		<h1 className="info__name" data-testid="heading">{label}</h1>
		<div className="Product__info">
		<label className="info__countInStock">In Stock - {countInStock}</label>
			<p className="info__name" data-testid="productName"><b>{name}</b></p>
			<p className="info__description">{description}</p>
			<p className="info__price">Rs {price}</p>
			
			{/* Add <Router> before Link for testing purpose only */}
			<Link to={`/product/${productId}`} className="info__button">View</Link>
			{/* Add <Router> before Link for testing purpose only */}
			<code>Product Id -{productId}</code>
		</div>
	</div>)
};
export default Product;